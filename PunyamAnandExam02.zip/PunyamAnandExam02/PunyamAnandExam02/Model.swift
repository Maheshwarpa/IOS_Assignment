//
//  Model.swift
//  PunyamAnandExam02
//
//  Created by Punyam Anand,Maheshwar on 11/14/23.
//

import Foundation


struct Item {
    var name: String = ""
    var brand: String = ""
    var unitsInStock: Int = 0
    var unitsSold: Int = 0
    var image: String = ""
    var price: Double = 0.0
}

struct AppConstants {
    static var electronicItems: [Item] = [
        Item(name: "Google Pixel 7 Pro", brand: "Google", unitsInStock: 10, unitsSold: 9, image: "gp7pro",price: 1200),
        Item(name: "iPad", brand: "Apple", unitsInStock: 25, unitsSold: 20, image: "iPad",price: 600),
        Item(name: "AirTag", brand: "Apple", unitsInStock: 10, unitsSold: 9, image: "airtag",price: 100),
        Item(name: "Headphones", brand: "Sony", unitsInStock: 30, unitsSold: 28, image: "headphones",price: 85)
        // add more items to electronicItems
    ]
    
    static var stationeryItems: [Item] = [
        Item(name: "Pen", brand: "Sharpie", unitsInStock: 20, unitsSold: 10, image: "pen",price: 3),
        Item(name: "Pencil", brand: "Wood Pencils", unitsInStock: 30, unitsSold: 22, image: "pencil",price: 2),
        Item(name: "Notebook", brand: "Pen Gear", unitsInStock: 50, unitsSold: 36, image: "notebook",price: 15.99),
        Item(name: "Marker", brand: "Crayola", unitsInStock: 25, unitsSold: 15, image: "marker",price: 85)
        // add more items to stationeryItems
    ]
}
