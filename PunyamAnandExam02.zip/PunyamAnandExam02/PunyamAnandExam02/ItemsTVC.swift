//
//  ItemsTVC.swift
//  PunyamAnandExam02
//
//  Created by Punyam Anand,Maheshwar on 11/14/23.
//

import UIKit

class ItemsTVC: UITableViewCell {

    
    @IBOutlet weak var titleLBL: UILabel!
    
    @IBOutlet weak var SubtitleLBL: UILabel!
    
    @IBOutlet weak var imageIV: UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
