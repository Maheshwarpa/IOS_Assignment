//
//  ItemDescriptionVC.swift
//  PunyamAnandExam02
//
//  Created by Punyam Anand,Maheshwar on 11/14/23.
//

import UIKit

class ItemDescriptionVC: UIViewController {

    var name = ""
    var brand = ""
    var price:Double = 0
    var img = ""
    
    @IBOutlet weak var itemIMG: UIImageView!
    
    @IBOutlet weak var itemNameLBL: UILabel!
    
    
    @IBOutlet weak var itemBrandLBL: UILabel!
    
    
    @IBOutlet weak var noOfUnitsInStockLBL: UILabel!
    
    @IBOutlet weak var noOfUnitsSoldLBL: UILabel!
    
    @IBOutlet weak var itemPriceLBL: UILabel!
    
    @IBOutlet weak var itemStatusLBL: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.itemNameLBL.text = name
        self.itemPriceLBL.text = "$\(price)"
        self.itemBrandLBL.text = brand
        self.itemIMG.image = UIImage(named: img)
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
