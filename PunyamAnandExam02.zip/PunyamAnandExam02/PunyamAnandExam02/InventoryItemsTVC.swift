//
//  InventoryItemsTVC.swift
//  PunyamAnandExam02
//
//  Created by Punyam Anand,Maheshwar on 11/14/23.
//

import UIKit

class InventoryItemsTVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var flag = false
    var temp:Item = Item()
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        switch section{
        case 0:
            return "Electronic Items"
        default:
            return "Stationary Items"
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section{
        case 0:
            return AppConstants.electronicItems.count
        default:
            return AppConstants.stationeryItems.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let section = indexPath.section
        
        switch section{
        case 0:
            let cell = inventoryItemsTV.dequeueReusableCell(withIdentifier: "stationary", for: indexPath) as! ItemsTVC
            cell.titleLBL?.text = AppConstants.electronicItems[indexPath.row].name
            cell.SubtitleLBL?.text = AppConstants.electronicItems[indexPath.row].brand
            cell.imageView?.image = UIImage(named: AppConstants.electronicItems[indexPath.row].image)
            return cell
        default:
            let cell = inventoryItemsTV.dequeueReusableCell(withIdentifier: "stationary", for: indexPath) as! ItemsTVC
            cell.titleLBL?.text = AppConstants.stationeryItems[indexPath.row].name
            cell.SubtitleLBL?.text = AppConstants.stationeryItems[indexPath.row].brand
            cell.imageView?.image = UIImage(named: AppConstants.stationeryItems[indexPath.row].image)
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let section = indexPath.section
        
        switch section{
        case 0:
            flag = true
            temp = AppConstants.electronicItems[indexPath.row]
        default:
            flag = false
            temp = AppConstants.stationeryItems[indexPath.row]
        }
        performSegue(withIdentifier: "descPage", sender: self)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return CGFloat(CFloat(50.0))
    }
    
    
    @IBOutlet weak var inventoryItemsTV: UITableView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        inventoryItemsTV.delegate=self
        inventoryItemsTV.dataSource=self
        // Do any additional setup after loading the view.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let id=segue.identifier,!id.isEmpty else{
            return
        }
        if(id == "descPage"){
            
            let destVC = segue.destination as! ItemDescriptionVC
            destVC.name = temp.name
            destVC.brand = temp.brand
            destVC.price = temp.price
            destVC.img = temp.image
        }
        
    }

//    override func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
//
//
//             let buy = UIContextualAction(style: .destructive, title: "Delete", handler: {_,_,_ in
//                 print("Hi")
//                 tableView.beginUpdates()
//                 print("ccccc at \(Constants.categoriesFromAPI[indexPath.row])")
//
//                 for (j,k) in AppConstants.electronicItems{
//                     for (index,m) in k.enumerated(){
//                         if(m.name.elementsEqual(AppConstants.electronicItems[indexPath.row])){
//                             AppConstants.electronicItems[j]?.remove(at: index)
//                             AppConstants.electronicItems.remove(at: index)
//                         }
//                     }
//                 }
//                 AppConstants.electronicItems.remove(at: indexPath.row)
//                 tableView.deleteRows(at: [indexPath], with: .fade)
//                 tableView.endUpdates()
//             })
//
//             let swipe = UISwipeActionsConfiguration(actions: [delete])
//             return swipe
//         }
    
//    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
////        let buy = UIContextualAction(style: .normal, title: "Buy", handler: {
////        -,-,- in
////            tableView.beginUpdates()
////            tableView.endUpdates()
////
////        })
//    }
//    
//    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
//        <#code#>
//    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
